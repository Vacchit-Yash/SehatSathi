# SehatSaathi — PROMPT ROCKERS
Team ID: PE-B81-11 | Team leader: Parth Sharma (S24CSEU2370)

## What this prototype does
A small offline, browser-based demonstration for public-health service navigation and visit preparation. It offers cautious next-step suggestions for common public services, a non-mandatory preparation checklist, and basic refusal/emergency overrides.

## Run
1. Download or clone this folder.
2. Open `index.html` in a modern browser. No server or API key is required.
3. Test the cases in `test-data/test-cases.csv` and record actual observed output in your Milestone 2 report.

## Important limitations
- This is a student prototype, not an official government service.
- It does not connect to a live facility directory and cannot identify the nearest facility.
- It does not verify service availability, facility hours, eligibility or document rules.
- It is not a clinical triage tool and must not diagnose or prescribe.
- The emergency keyword check is a simple demonstration rule and is not comprehensive.
- English/Hindi is shown as a language preference control; the current generated guidance is English. Do not claim Hindi output support yet.
- No personal identifiers should be entered.

## Team
- Parth Sharma — S24CSEU2370 (Team leader)
- Kunal Raj — S24CSEU2411
- Rudra Pratap Singh — S24CSEU2396
- Yashvardhan Singh — S24CSEU2406
- Sushant Kumar — S24CSEU2413
- Prashant Kumar — S24CSEU2415

## Before submission
Capture genuine screenshots of real runs; record actual outputs and Pass/Fail. Add dated progress evidence. Publish the folder/repository with evaluator view access and test it in a private/incognito window. Do not claim all modules work unless each has been tested.
