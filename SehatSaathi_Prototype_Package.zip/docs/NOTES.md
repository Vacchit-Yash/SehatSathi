Capture 2–3 real screenshots from browser runs and place them here. Add diagrams that match the implemented prototype. Do not add mockups as demonstration evidence.
